var alien_color_version1 = 'green';
if (alien_color_version1 === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the green alien!");
}
else if (alien_color_version1 === 'yellow') {
    console.log("Congratulations! You just earned 10 points for shooting the yellow alien!");
}
else if (alien_color_version1 === 'red') {
    console.log("Congratulations! You just earned 15 points for shooting the red alien!");
}
var alien_color_version2 = 'yellow';
if (alien_color_version2 === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the green alien!");
}
else if (alien_color_version2 === 'yellow') {
    console.log("Congratulations! You just earned 10 points for shooting the yellow alien!");
}
else if (alien_color_version2 === 'red') {
    console.log("Congratulations! You just earned 15 points for shooting the red alien!");
}
var alien_color_version3 = 'red';
if (alien_color_version3 === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the green alien!");
}
else if (alien_color_version3 === 'yellow') {
    console.log("Congratulations! You just earned 10 points for shooting the yellow alien!");
}
else if (alien_color_version3 === 'red') {
    console.log("Congratulations! You just earned 15 points for shooting the red alien!");
}
