let alien_color_pass: string = 'green';

if (alien_color_pass === 'green') {
    console.log("Congratulations! You just earned 5 points!");
}

let alien_color_fail: string = 'red';

if (alien_color_fail === 'green') {
    console.log("Congratulations! You just earned 5 points!");
}