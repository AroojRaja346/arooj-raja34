var alien_color_pass = 'green';
if (alien_color_pass === 'green') {
    console.log("Congratulations! You just earned 5 points!");
}
var alien_color_fail = 'red';
if (alien_color_fail === 'green') {
    console.log("Congratulations! You just earned 5 points!");
}
