function make_shirt(size, message) {
    console.log("The shirt size is ".concat(size, " and it has the message: \"").concat(message, "\""));
}
// Calling the function
make_shirt("Medium", "Hello, World!");
