

const names: string[] = ["John", "Bob", "Pretty"];

for (let i: number = 0; i < names.length; i++) {
    const element: string = names[i];
    console.warn(`Hey! This is ${element}`);
}

