function city_country(city, country) {
    return "".concat(city, ", ").concat(country);
}
// Calling the function with different city-country pairs
var result1 = city_country("Lahore", "Pakistan");
console.log(result1);
var result2 = city_country("Paris", "France");
console.log(result2);
var result3 = city_country("Sydney", "Australia");
console.log(result3);
