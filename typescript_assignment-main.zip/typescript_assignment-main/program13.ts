

const motorcycles: string[] = ["Honda", "Kawasaki", "Yamaha", "Suzuki"];

for (let i: number = 0; i < motorcycles.length; i++) {
    console.log(`I would like to own a ${motorcycles[i]} motorcycle.`);
}