
var names = ["John", "Bob", "Pretty"];
for (var i = 0; i < names.length; i++) {
    var element = names[i];
    console.warn("Hey! This is ".concat(element));
}
