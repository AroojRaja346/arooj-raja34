// // Define the Fruit interface
// interface Fruit {
//     name: string;
//     color: string;
//     taste: string;
// }
// Create fruit objects
var apple = {
    name: "Apple",
    color: "Red",
    taste: "Sweet"
};
var banana = {
    name: "Banana",
    color: "Yellow",
    taste: "Sweet"
};
var lemon = {
    name: "Lemon",
    color: "Yellow",
    taste: "Sour"
};
// Output the fruit objects
console.log(apple);
console.log(banana);
console.log(lemon);
