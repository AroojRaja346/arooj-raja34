var favorite_pizzas = ['Pepperoni', 'Margherita', 'Hawaiian'];
for (var i = 0; i < favorite_pizzas.length; i++) {
    console.log("I like ".concat(favorite_pizzas[i], " pizza."));
}
console.log("I really love pizza!");
