var alien_color_if = 'green';
if (alien_color_if === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the alien!");
}
else {
    console.log("Congratulations! You just earned 10 points for shooting the alien!");
}
var alien_color_else = 'red';
if (alien_color_else === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the alien!");
}
else {
    console.log("Congratulations! You just earned 10 points for shooting the alien!");
}
