
var motorcycles = ["Honda", "Kawasaki", "Yamaha", "Suzuki"];
for (var i = 0; i < motorcycles.length; i++) {
    console.log("I would like to own a ".concat(motorcycles[i], " motorcycle."));
}
