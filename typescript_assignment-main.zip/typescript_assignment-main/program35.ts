let animals: string[] = ['Dog', 'Cat', 'Rabbit'];

for (let i = 0; i < animals.length; i++) {
    console.log(animals[i]);
}

console.log("");

for (let i = 0; i < animals.length; i++) {
    console.log(`A ${animals[i].toLowerCase()} would make a great pet.`);
}

console.log("Any of these animals would make a great pet!");