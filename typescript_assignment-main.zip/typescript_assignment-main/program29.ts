let favorite_fruits: string[] = ['apple', 'banana', 'mango'];

if (favorite_fruits.indexOf('apple')) {
    console.log("You really like apples!");
}

if (favorite_fruits.indexOf('banana')) {
    console.log("You really like bananas!");
}

if (favorite_fruits.indexOf('mango')) {
    console.log("You really like mangoes!");
}

if (favorite_fruits.indexOf('orange')) {
    console.log("You really like oranges!");
}

if (favorite_fruits.indexOf('strawberry')) {
    console.log("You really like strawberries!");
}