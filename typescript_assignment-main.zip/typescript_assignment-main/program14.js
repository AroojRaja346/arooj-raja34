
var guests = ["Alex", "Shrack", "Charlie"];
for (var i = 0; i < guests.length; i++) {
    var element = guests[i];
    console.warn("Dear ".concat(element, ",\n\n    I'm a passionate developer and I'd like to invite you over for dinner tonight so we can share our experiences.\n\n    Sincerely,\n    Your Friend\n    "));
}
