const names = ["Name1", "Name2", "Name3"];

for (let i = 0; i < names.length; i++) {
    const element = names[i];
    console.warn(element)

}