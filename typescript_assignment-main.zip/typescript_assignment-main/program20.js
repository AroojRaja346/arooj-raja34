// const mountains = [
//     "Mount Everest",
//     "K2",
//     "Kangchenjunga",
//     "Lhotse",
//     "Makalu",
//     "Cho Oyu",
//     "Dhaulagiri",
//     "Manaslu",
//     "Annapurna I",
// ];
// console.log(mountains);
var mountains = [
    "Mount Everest",
    "K2",
    "Kangchenjunga",
    "Lhotse",
    "Makalu",
    "Cho Oyu",
    "Dhaulagiri",
    "Manaslu",
    "Annapurna I",
];
console.log(mountains);
