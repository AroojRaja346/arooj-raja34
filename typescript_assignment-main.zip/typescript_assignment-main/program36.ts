function make_shirt(size: string, message: string): void {
    console.log(`The shirt size is ${size} and it has the message: "${message}"`);
}

// Calling the function
make_shirt("Medium", "Hello, World!");