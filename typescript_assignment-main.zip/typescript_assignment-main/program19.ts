// const guests = ["Alex", "Shrack"]

// console.warn(`
// From the above Exercise 14 through 18 only 2 peoples are invited to the dinner
// ${guests}
// `)

const guests: string[] = ["Alex", "Shrack"];

console.warn(`
From the above Exercise 14 through 18 only 2 peoples are invited to the dinner
${guests}
`);