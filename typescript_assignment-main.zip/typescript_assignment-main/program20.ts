// const mountains = [
//     "Mount Everest",
//     "K2",
//     "Kangchenjunga",
//     "Lhotse",
//     "Makalu",
//     "Cho Oyu",
//     "Dhaulagiri",
//     "Manaslu",
//     "Annapurna I",
// ];

// console.log(mountains);


const mountains: string[] = [
    "Mount Everest",
    "K2",
    "Kangchenjunga",
    "Lhotse",
    "Makalu",
    "Cho Oyu",
    "Dhaulagiri",
    "Manaslu",
    "Annapurna I",
];

console.log(mountains);