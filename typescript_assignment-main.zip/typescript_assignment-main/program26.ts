let alien_color_if: string = 'green';

if (alien_color_if === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the alien!");
} else {
    console.log("Congratulations! You just earned 10 points for shooting the alien!");
}

let alien_color_else: string = 'red';

if (alien_color_else === 'green') {
    console.log("Congratulations! You just earned 5 points for shooting the alien!");
} else {
    console.log("Congratulations! You just earned 10 points for shooting the alien!");
}